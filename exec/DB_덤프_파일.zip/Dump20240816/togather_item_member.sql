-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item_member`
--

DROP TABLE IF EXISTS `item_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_id` int DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKfn5iljrkw7e1nt81x9sq48pcg` (`item_id`),
  KEY `FKf8vb4cc4ytdtqdivyan4o3bto` (`member_id`),
  CONSTRAINT `FKf8vb4cc4ytdtqdivyan4o3bto` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKfn5iljrkw7e1nt81x9sq48pcg` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_member`
--

LOCK TABLES `item_member` WRITE;
/*!40000 ALTER TABLE `item_member` DISABLE KEYS */;
INSERT INTO `item_member` VALUES (1,1,1),(2,1,3),(3,1,2),(4,1,4),(5,2,1),(6,2,3),(7,2,2),(8,2,4),(9,3,4),(10,3,2),(11,3,3),(12,3,1),(13,3,5),(14,4,4),(15,4,2),(16,4,3),(17,4,1),(18,4,5),(19,5,4),(20,5,2),(21,5,3),(22,5,1),(23,5,5),(24,6,4),(25,6,2),(26,6,3),(27,6,1),(28,6,5),(29,7,4),(30,7,2),(31,7,3),(32,7,1),(33,7,5),(34,8,2),(35,9,1),(36,10,9),(37,11,1),(38,11,2),(39,12,1),(40,13,1),(41,14,9),(42,15,9),(43,15,8),(44,16,8),(45,16,10),(46,17,10),(47,17,8),(48,18,8),(49,19,8),(50,20,8),(51,21,8),(52,22,8),(53,23,3),(54,23,10),(55,24,3),(56,24,10),(57,25,3),(58,25,10),(59,26,3),(60,26,10),(61,27,3),(62,27,10),(63,28,3),(64,28,10),(65,29,3),(66,29,10),(67,30,3),(68,30,10),(69,31,10),(72,34,2),(79,40,2),(80,41,9),(81,42,1),(82,43,2),(83,43,9),(84,44,1),(85,44,9),(86,44,2),(104,49,2),(105,49,9),(106,49,10),(107,50,4),(108,50,5),(109,50,8),(110,51,2),(111,51,4),(112,51,5),(113,51,9),(114,51,8),(115,51,10),(116,52,2),(117,52,4),(118,52,9),(119,52,8),(120,52,10),(141,63,2),(142,63,1),(143,63,9),(144,64,2),(145,64,1),(146,64,9),(147,65,2),(148,65,1),(149,65,9),(150,66,2),(151,66,1),(152,66,9),(153,67,2),(154,67,9),(155,68,1),(156,69,2),(157,69,1),(158,69,9),(159,70,2),(160,71,2),(161,72,2),(162,73,2),(163,74,2),(164,75,1),(165,76,9),(166,77,10),(167,78,9),(168,78,1),(169,79,2),(170,79,1),(171,79,9),(172,80,2),(173,80,1),(174,80,9),(175,81,2),(176,81,9),(177,81,1),(178,82,2),(179,82,1),(180,83,8),(181,83,9),(182,84,8),(183,84,9),(184,85,8),(185,85,9),(186,86,8),(187,86,9),(188,86,2),(189,87,9),(190,87,8),(191,88,2),(192,89,8),(193,89,9),(194,89,2),(195,90,8),(196,91,9),(197,92,2),(198,93,9),(199,93,8),(200,94,9),(201,94,8),(202,94,2);
/*!40000 ALTER TABLE `item_member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:03
