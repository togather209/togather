-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_img` varchar(255) DEFAULT NULL,
  `type` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKmbmcqelty0fbrvxp1q58dn57t` (`email`),
  UNIQUE KEY `UKhh9kg6jti4n1eoiertn2k6qsc` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'bumdoly200@naver.com','김범규','KBG','$2a$10$3RxNg8.oVP9YgI5i4JqyA.fF..KvOqazALIJIVocQQrIJEbbXusL2','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|52633898-eee0-4749-8e7f-f90db5d19d9c.png',0),(2,'wjd4782@naver.com','장정현','정현2','$2a$10$2PxTpjRTlT5nGtzMUjCjjODZqmUE/dOl3SEnqk7hrVnnarM3UI..G','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|64738bdb-16e0-4d71-b037-385469bb18c2.png',0),(3,'tjensk26@naver.com',NULL,'냠냠','KAKAO','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|8ad3e96a-2416-4d2c-994c-776d1f5df211.png',1),(4,'bumdoly2000@naver.com',NULL,'김범규','KAKAO','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|d0869667-cee5-451d-9cc6-11fb6ffc4669.png',1),(5,'ksh219805@hanmail.net','김선하','김선하','KAKAO',NULL,1),(6,'togeth@gmail.com','TOGATHER','TOGATHER','TOGATHER',NULL,1),(7,'1514kth@naver.com',NULL,'김밤구','KAKAO',NULL,1),(8,'hyeee19@naver.com','이지혜','지혱','$2a$10$I7tgSO5lP/6rDGHriIBHg.A4WpiiWo66498hEKjX3wSkGau7GRIqu','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|0e4f0a8b-561e-420a-a17b-7c1189730d56.png',0),(9,'gotnsla12@naver.com','김해수','해수님','$2a$10$olhgpG5ck2Mr.FNXAmtP1eHWyFJZ4qMOO1NpzefZCUaX3hqUbn/w2','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|379f2ebf-cc55-47c8-81c3-7455ac648896.png',0),(10,'tjensk26@gmail.com','서두나','두나','$2a$10$TG8UqkxjsEqdBcErJedxmOCjwny4/l6Yezpx1BK2QME4uxbJ5UZRe','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|5f1a2651-39a7-43fe-9d24-0ca358e9ecc1.png',0),(11,'togather871@gmail.com','김싸피','테스트','$2a$10$lpGTCkKRd8N8NtHHYQFQJOk8hWy7J829vwXR2VV72OyYEYkQdAhSO','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|97fd36b6-d7df-46da-b942-c45ccdf68b65.png',0);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:04
