-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `team_img` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'KWO1HE6W','같이 빵먹으면서 친해져요~~','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|fb452a07-2145-445c-862f-b69647147a27.png','빵을 사랑하는 모임'),(2,'FGKPOER0','범구가 또 볼링치자는디','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|89a4f2ab-2b5e-41b4-8a74-067c1efc9c6b.png','볼링그만쳐'),(3,'5U40AJBR','ㅎㅀ롷롷롷ㄺㄴㅅㅎㄴㅇㄿㄻㄱㄻㄴㅇㄻㄷㄻㅇㅇㅎㄹㅇㄶㅁㄷㄱㄹㅇㄴㄹㅇㅍ로ㅓㅗㅛㅅㄱㄱㄶㅁㅎ루허ㅗㅓㅕㅏㅓㅗㄱㅎ률ㄹㄴㅇ','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|2ce6b798-4af7-4e74-a9de-809f7d9c9335.jpg','ㅁㄴㅇㄻㄴㅇㄻㅇㄴㄻㅇㄴㄻㅇㄴㄻㄴㅇㄹㅇㄹㅇㄹㅇㄴㅇㄻㅇㄻㅇㄹㄷㄻㅇㄻㅇㄴㄹㄷㅁㅇㄹㅇㄹㅈㄷㄱㅁㄷㄹㅇㄻㄷㄻㅇㄻㄴㄹㅇㄻㄷㄻㅇㄹㅇㄹㅇㅁㄹㄷㄻㄷㄹㅇㄻㅇㄻㅈㄷㄻㅈㄷㅎㅍㅍㅊㅌㅍㅁㅇㄹㄴㅁㅇㄹㅇㄴㅇㄻㅇㄹㅇㅍㅊㅍㅁㄴㄹㄴㅇㄹ'),(6,'QOBDHIMR','카페 가죠?','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|ec6a8452-ff4b-4d5d-b6d6-319dd17b3341.png','대전 카페'),(10,'VPI2WMNM','해수야 와라','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|2ce6b798-4af7-4e74-a9de-809f7d9c9335.jpg','발표준비할게염'),(11,'X1NWPYAU','커피 한잔 할래요??','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|f9ce62c2-5440-473b-9431-80c5726c7205.png','커피 한잔☕️'),(12,'YSGRTMTZ','ssafy 멤버들 와주세요~','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|26da42b9-3428-4a92-8584-61932dda85fe.png','SSAFY 모임'),(14,'RY1UADXH','ssafy 모임입니다.','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|25f32326-8cbe-4fbd-a871-f35acd94ebe9.png','ssafy 모임'),(16,'Y23NR3GJ','맛집!!','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|68a2effb-98af-45e3-bda1-3f7f8c12a7e3.png','맛집탐방'),(17,'QO3AFQQ1','test','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|6429ccf1-aa5e-4982-966f-9ab053e1f9ca.png','test'),(18,'RDGCEK00','test','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|4a8609e5-5b31-4d79-a528-1c583635625b.png','test'),(19,'SXX663SS','가자','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|d54f2b04-034c-4368-8a5d-2893dc9ef86c.png','밥 먹자'),(20,'WEMHWW0S','싸피 사람들의 모임','https://trip-bucket-0515.s3.ap-northeast-2.amazonaws.com/|bb718421-86a5-4564-8406-bad538d2e8a7.png','싸모임');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:10
