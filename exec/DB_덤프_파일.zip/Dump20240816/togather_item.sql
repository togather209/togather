-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item` (
  `id` int NOT NULL AUTO_INCREMENT,
  `count` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `unit_price` int NOT NULL,
  `receipt_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8s305nsnv4wi5iuh7kkr52gqt` (`receipt_id`),
  CONSTRAINT `FK8s305nsnv4wi5iuh7kkr52gqt` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item`
--

LOCK TABLES `item` WRITE;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` VALUES (1,1,'불고기세트',7100,1),(2,1,'포텐불고기',7700,1),(3,1,'탈덕포도',0,2),(4,1,'작은구슬 조코',2000,2),(5,1,'와일드바디',0,2),(6,1,'작은구슬 레인보우',2000,2),(7,1,'DILR',2000,2),(8,1,'삼립) 로켓단초코1885g',1500,3),(9,1,'오리온) 예감볶음은1064g',1500,3),(10,1,'오리온)예감치즈그라탕64g',1500,3),(11,2,'이노엔) 티로그복숭아아이',2200,3),(12,1,'코카)태양의D| 타자500ml',1400,3),(13,1,'롯데)빠다고코난100g',1600,3),(14,1,'해태) 초코홈런높469g',1200,3),(15,2,'동화)생생톤210ml병',1500,3),(16,1,'웅진) 아침햇살58ml',2000,3),(17,1,'친환경 비닐쇼핑백_100원',1000,3),(18,1,'1. 탱탱포도',0,4),(19,1,'착용구슬 초코',2000,4),(20,1,'와일드바디',600,4),(21,1,'작은구슬 레인보우',2000,4),(22,1,'5 미니구etHULL',2000,4),(23,25,'생삼겹살',175000,5),(24,4,'맥주',12000,5),(25,4,'음료수',4000,5),(26,13,'밥+된장',26000,5),(27,1,'해표더고소한김16봉',3,6),(28,1,'깊은산속맑은알30구',4496,6),(29,1,'대림/곤약250g',1000,6),(30,1,'*연근채',1300,6),(31,1,'욕설탕버들일크티(ICED ONLY)',480000,7),(34,1,'버블밀크티(ICED DNLY)',4800000,10),(40,1,'모토포도',0,12),(41,1,'작용구슬 조크',2000,12),(42,1,'와일드바디',600,12),(43,1,'작은구슬 레이보오',2000,12),(44,1,'품목명',2000,12),(49,3,'순한맛',39000,14),(50,3,'중간맛',39000,14),(51,6,'공기밥',6000,14),(52,1,'참이슬',5000,14),(63,1,'담당포도',600,16),(64,1,'잡은구슬 조커',2000,16),(65,1,'와일드바디',500,16),(66,1,'작은구슬 레인보우',2000,16),(67,1,'아메리카노',4500,17),(68,1,'아이스티',5500,17),(69,1,'4시간 이용',32000,18),(70,1,'탱탱포도',800,19),(71,1,'작은 구슬 초코',2000,19),(72,1,'와일드 바디',600,19),(73,1,'미니구슬 바나나',2000,19),(74,1,'탱탱포도',600,20),(75,1,'작은구슬 초코',2000,20),(76,1,'와일드바디',600,20),(77,1,'작은구슬 레인보우',2000,20),(78,1,'미니구슬비나나',2000,20),(79,1,'불고기세트',7100,21),(80,1,'포텐불고기',7700,21),(81,3,'아메리카노',4000,22),(82,2,'와플',4000,22),(83,1,'AB 레티500ml',1200,23),(84,3,'실습용?',1000,23),(85,1,'### 파 게트 번역',1000,23),(86,1,'불고기세트',7100,24),(87,3,'품목명',39000,25),(88,3,'품목명',39000,25),(89,6,'공기밥',6,25),(90,1,'1.탱탱포도',600,26),(91,1,'2.작은구슬 초코',2000,26),(92,1,'3.와일드바디',600,26),(93,1,'4 작은구슬 레인보우',2000,26),(94,1,'5 ml',2000,26);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:10
