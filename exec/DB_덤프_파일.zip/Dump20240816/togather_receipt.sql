-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `receipt`
--

DROP TABLE IF EXISTS `receipt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receipt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `business_name` varchar(255) NOT NULL,
  `color` int NOT NULL,
  `payment_date` datetime(6) NOT NULL,
  `total_price` int NOT NULL,
  `bookmark_id` int DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKq6qiah41u2gxvddy2dtv7up8p` (`bookmark_id`),
  KEY `FK2s7sws87bynqjgo121cgaqas5` (`member_id`),
  KEY `FKqv8jsy43h5jmwcerbphgx97iy` (`plan_id`),
  CONSTRAINT `FK2s7sws87bynqjgo121cgaqas5` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FKq6qiah41u2gxvddy2dtv7up8p` FOREIGN KEY (`bookmark_id`) REFERENCES `bookmark` (`id`),
  CONSTRAINT `FKqv8jsy43h5jmwcerbphgx97iy` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receipt`
--

LOCK TABLES `receipt` WRITE;
/*!40000 ALTER TABLE `receipt` DISABLE KEYS */;
INSERT INTO `receipt` VALUES (1,'LOTTERIA',2,'2024-08-14 00:00:00.000000',14800,NULL,3,1),(2,'노을1960호',0,'2024-08-15 00:00:00.000000',6000,NULL,2,2),(3,'세븐일레트',1,'2024-08-15 00:00:00.000000',15400,NULL,8,2),(4,'얼왕 대전',0,'2024-08-15 00:00:00.000000',6600,NULL,10,2),(5,'한돈당',2,'2024-08-15 00:00:00.000000',217000,NULL,10,4),(6,'럭키할인마트',0,'2024-08-15 00:00:00.000000',6799,NULL,10,4),(7,'커피',0,'2024-08-15 00:00:00.000000',480000,NULL,3,4),(10,'커피니',2,'2024-08-15 00:00:00.000000',4800000,NULL,10,6),(12,'얼왕 대전 노은199호점',1,'2024-08-15 00:00:00.000000',6600,79,2,11),(14,'순희네',1,'2024-08-15 00:00:00.000000',89000,NULL,8,7),(16,'업자변모',1,'2024-08-15 00:00:00.000000',5100,NULL,2,12),(17,'스터디 카페',2,'2024-08-15 00:00:00.000000',10000,86,1,13),(18,'윙스터디카페',1,'2024-08-18 00:00:00.000000',32000,84,2,13),(19,'대전 노은199호접',2,'2024-08-15 00:00:00.000000',5400,90,9,13),(20,'아이스크림',1,'2024-08-15 00:00:00.000000',7200,91,10,13),(21,'카페',1,'2024-08-15 00:00:00.000000',14800,98,1,17),(22,'비래키키',2,'2024-08-31 00:00:00.000000',8000,99,2,17),(23,'대저 노트',2,'2024-08-15 00:00:00.000000',3200,NULL,8,22),(24,'LOTTERIA',0,'2024-08-15 00:00:00.000000',7100,NULL,2,22),(25,'순의네',2,'2024-08-15 00:00:00.000000',78006,NULL,2,22),(26,'얼왕 대전',0,'2024-08-15 00:00:00.000000',7200,110,8,22);
/*!40000 ALTER TABLE `receipt` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:05
