-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmark` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `item_order` int DEFAULT NULL,
  `place_addr` varchar(255) DEFAULT NULL,
  `place_id` varchar(255) NOT NULL,
  `place_img` varchar(255) DEFAULT NULL,
  `place_name` varchar(255) NOT NULL,
  `plan_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdrm4osyt8iyut264gy9lecsil` (`plan_id`),
  CONSTRAINT `FKdrm4osyt8iyut264gy9lecsil` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmark`
--

LOCK TABLES `bookmark` WRITE;
/*!40000 ALTER TABLE `bookmark` DISABLE KEYS */;
INSERT INTO `bookmark` VALUES (22,NULL,0,'대전 유성구 봉명동 682-2','200882001','/src/assets/search/restaurant.jpg','원조태평소국밥 본관',2),(23,'2024-08-17',2,'대전 동구 삼성동 304-36','16302660','/src/assets/search/restaurant.jpg','오씨칼국수',2),(26,NULL,0,'대전 서구 갈마동 1080','1977810669','/src/assets/search/restaurant.jpg','청년주막',2),(27,'2024-08-18',1,'대전 중구 오류동 116-3','10822423','/src/assets/search/market.jpg','코스트코 대전점',2),(38,'2024-08-18',0,'충남 태안군 소원면 의항리 868','8082599','/src/assets/search/attraction.jpg','천리포수목원',1),(39,'2024-08-17',4,'서울 강남구 도곡동 947-17','1784776349','/public/defaultimage.png','집 강남점',2),(40,'2024-08-17',7,'서울 서초구 양재동 341-10','196338341','/public/defaultimage.png','집 양재점',2),(41,'2024-08-17',1,'서울 송파구 잠실동 208-8','1788974091','/public/defaultimage.png','집 잠실점',2),(44,'2024-08-17',0,'충남 부여군 부여읍 구아리 114-6','844214580','/public/defaultimage.png','집',2),(45,'2024-08-18',0,'전남 여수시 소호동 360-9','726318384','/src/assets/search/restaurant.jpg','집',2),(58,'2024-08-18',3,'인천 강화군 화도면 동막리 7-3','7842020','/src/assets/search/attraction.jpg','동막해수욕장',1),(60,'2024-08-17',3,'대전 중구 대흥동 3-16','11006001','/src/assets/search/restaurant.jpg','대전갈비집',2),(61,'2024-08-18',2,'대전 동구 소제동 293-9','27446255','/public/defaultimage.png','대전역 동광장',1),(64,'2024-08-18',1,'대전 유성구 덕명동 16-1','8638145','/public/defaultimage.png','국립한밭대학교 유성덕명캠퍼스 정문',1),(65,NULL,0,'대전 유성구 덕명동 16-1','17566674','/public/defaultimage.png','한밭대학교 아트홀',1),(66,NULL,0,'경기 의정부시 용현동 81-3','2018315048','/src/assets/search/restaurant.png','밥집',1),(67,NULL,0,'경기 용인시 기흥구 동백동 613-5','850621246','/src/assets/search/restaurant.png','밥집',1),(68,NULL,0,'대전 유성구 지족동 901-5','168312184','/public/defaultimage.png','T world 해온대리점 노은역점',1),(69,NULL,0,'대전 유성구 지족동 901-3','158234226','/src/assets/search/restaurant.png','60계 대전노은역점',1),(76,'2024-08-16',2,'경기 시흥시 안현동 산 49','27006404','/src/assets/search/attraction.png','양지산',11),(77,'2024-08-16',1,'경기 시흥시 안현동','10794929','/public/defaultimage.png','중림고개',11),(78,'2024-08-17',0,'경기 시흥시 은행동 646-6','1121800768','/public/defaultimage.png','올리브영 시흥은계점',11),(79,'2024-08-16',0,'경기 시흥시 은행동 646-10','1664009078','/src/assets/search/cafe.png','벌툰 파리지앵 시흥은계점',11),(80,NULL,0,'대전 대덕구 장동 453-1','17990917','/src/assets/search/attraction.png','계족산 황톳길',11),(81,NULL,0,'충남 태안군 원북면 방갈리 515-121','8650114','/src/assets/search/attraction.png','학암포해수욕장',1),(82,NULL,0,'충남 태안군 원북면 방갈리 515-79','772862648','/src/assets/search/accomodation.png','학암포오토캠핑장',1),(83,NULL,0,'인천 미추홀구 용현동 672-1','1530481819','/src/assets/search/subway.png','인하대역 수인분당선',1),(84,'2024-08-18',2,'대전 서구 둔산동 1010','26782072','/public/defaultimage.png','윙스터디카페 대전둔산점',13),(85,'2024-08-17',1,'대전 유성구 상대동 439-2','1966213123','/public/defaultimage.png','화이트펜슬스터디카페 유성상대점',13),(86,'2024-08-16',0,'대전 유성구 봉명동 552-2','1726389589','/public/defaultimage.png','그로잉스터디카페 대전충남대점',13),(87,'2024-08-17',0,'대전 중구 문화동 311-12','741157077','/public/defaultimage.png','데일리스터디카페 문화점',13),(88,NULL,0,'대전 서구 월평동 540','1704008231','/public/defaultimage.png','월평스터디카페',13),(89,'2024-08-18',4,'대전 유성구 지족동 907-3','22547066','/src/assets/search/cafe.png','스타벅스 대전노은점',13),(90,'2024-08-17',2,'대전 유성구 지족동 907-1','7954599','/src/assets/search/conviny.png','세븐일레븐 대전노은점',13),(91,'2024-08-18',3,'대전 유성구 지족동 906-3','873759391','/public/defaultimage.png','만점스터디카페',13),(92,'2024-08-18',0,'대전 유성구 지족동 905-5','449766433','/public/defaultimage.png','스터디나인독서실',13),(94,'2024-08-18',1,'대전 유성구 노은동 499-3','1852935631','/src/assets/search/cafe.png','백정화',13),(95,NULL,0,'대전 유성구 노은동 288-30','322382205','/src/assets/search/cafe.png','더노은로',13),(96,'2024-08-30',3,'대전 동구 신촌동 362-4','25624861','/src/assets/search/cafe.png','팡시온',17),(97,'2024-08-30',0,'대전 대덕구 용호동 53','1285491913','/src/assets/search/cafe.png','두두당',17),(98,'2024-08-30',2,'대전 서구 둔산동 984','9648677','/src/assets/search/cafe.png','홀리크로스',17),(99,'2024-08-31',0,'대전 대덕구 비래동 437','787212968','/src/assets/search/cafe.png','비래키키',17),(100,'2024-08-29',1,'대전 유성구 궁동 244-4','1429359605','/src/assets/search/cafe.png','커피인터뷰 궁동점',17),(101,'2024-08-31',1,'대전 유성구 봉명동 615-6','2070748723','/src/assets/search/cafe.png','아케이드커피',17),(102,'2024-08-30',1,'대전 서구 관저동 1952-3','1406762793','/public/defaultimage.png','플랜에이스터디카페 대전관저센터',17),(103,'2024-08-29',0,'대전 서구 괴정동 5-9','27355811','/public/defaultimage.png','토즈스터디센터 대전탄방롯데센터',17),(104,'2024-08-28',0,'서울 마포구 동교동 146-8','1797970569','/src/assets/search/cafe.png','카페공명 연남점',17),(105,'2024-08-29',2,'부산 남구 대연동 1786-19','127010426','/src/assets/search/cafe.png','메그네이트',17),(106,'2024-08-29',3,'인천 옹진군 영흥면 선재리 636-10','341506592','/src/assets/search/cafe.png','플로레도커피 선재점',17),(107,'2024-08-28',1,'제주특별자치도 제주시 도두일동 1732-9','373077516','/src/assets/search/cafe.png','카페나모나모',17),(108,'2024-08-28',2,'서울 중구 명동2가 105','87323834','/src/assets/search/cafe.png','더스팟 패뷸러스',17),(109,'2024-08-19',0,'대전 유성구 도룡동 4-19','1148545656','/src/assets/search/restaurant.png','성심당 DCC점',22),(110,'2024-08-18',2,'대전 동구 삼성동 304-36','16302660','/src/assets/search/restaurant.png','오씨칼국수',22),(111,'2024-08-17',0,'대전 유성구 도룡동 4-30','23700427','/src/assets/search/accomodation.png','롯데시티호텔 대전',22),(112,'2024-08-18',3,'대전 유성구 봉명동 545-5','7967564','/src/assets/search/accomodation.png','호텔인터시티',22),(113,'2024-08-17',1,'대전 서구 둔산동 1052','12295553','/src/assets/search/conviny.png','GS25 타임월드점',22),(114,NULL,0,'대전 중구 문화동 1-226','8576722','/src/assets/search/facility.png','CGV 대전',22),(115,'2024-08-18',0,'대전 유성구 봉명동 682-2','200882001','/src/assets/search/restaurant.png','원조태평소국밥 본관',22),(116,NULL,0,'대전 중구 선화동 52-2','8209640','/src/assets/search/restaurant.png','광천식당',22),(117,'2024-08-17',2,'대전 서구 갈마동 273-19','1167148493','/src/assets/search/restaurant.png','킨토토',22),(118,'2024-08-17',3,'대전 대덕구 비래동 437','787212968','/src/assets/search/cafe.png','비래키키',22),(119,'2024-08-18',1,'대전 서구 둔산동 984','9648677','/src/assets/search/cafe.png','홀리크로스',22),(120,NULL,0,'대전 서구 탄방동 744','26523358','/src/assets/search/facility.png','CGV 대전탄방',22);
/*!40000 ALTER TABLE `bookmark` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:06
