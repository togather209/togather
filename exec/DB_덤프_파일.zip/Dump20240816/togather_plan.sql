-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i11b209.p.ssafy.io    Database: togather
-- ------------------------------------------------------
-- Server version	9.0.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `plan`
--

DROP TABLE IF EXISTS `plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `end_date` date NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `status` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `member_id` int DEFAULT NULL,
  `team_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8ib1c8odrbn5firtedh1wilgl` (`member_id`),
  KEY `FK548pp6vycxv0g26dxtlx5na46` (`team_id`),
  CONSTRAINT `FK548pp6vycxv0g26dxtlx5na46` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`),
  CONSTRAINT `FK8ib1c8odrbn5firtedh1wilgl` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plan`
--

LOCK TABLES `plan` WRITE;
/*!40000 ALTER TABLE `plan` DISABLE KEYS */;
INSERT INTO `plan` VALUES (1,'푸른소리 파이팅','2024-08-18','ses_NR1Xl5fvP5','2024-08-17',1,'태안 엠티',1,1),(2,'주번','2024-08-18','ses_FmkkScGt2W','2024-08-17',3,'주말 번개 모임',2,1),(3,'여향','2024-08-31','ses_FoGO33RslM','2024-08-15',0,'대전',2,1),(4,'내일 아침에 같이 싸피 가자','2024-08-16','ses_Ql7N6XDrlX','2024-08-15',3,'밤샘 코딩팟',10,1),(6,'맛있바','2024-08-15','ses_WJF9EMukv4','2024-08-15',1,'미숫가루',10,1),(7,'피곤','2024-08-17','ses_P43EIDHJPY','2024-08-16',0,'피곤',2,1),(9,'커피먹구 싶어요','2024-08-17','ses_QqNHOc7DGN','2024-08-15',0,'둔산동 카페갈사람??',2,6),(10,'24일까지 빡공','2024-08-24','ses_HIMwvcOSpm','2024-08-15',0,'유온 스터디',1,6),(11,'백화점 구경갈사람','2024-08-20','ses_UXJVTxh37b','2024-08-16',3,'은행동 나들이',2,6),(12,'ㅎㅎㅎ','2024-08-16','ses_XcuwpYLWQC','2024-08-16',3,'ㅎㅎ',2,10),(13,'해커톤 준비합시다!','2024-08-18','ses_UW5h8CuD54','2024-08-16',3,'SSAFY 해커톤',1,12),(14,'공통프로젝트 중 정산입니다','2024-08-29','ses_TCM80Qw08I','2024-08-21',0,'공통프로젝트',2,12),(15,NULL,'2024-08-30','ses_WxZiELf3a1','2024-08-28',0,'축구를 사랑하는 모임',2,12),(16,'주에 1영화','2024-08-23','ses_YJJOLFrtXz','2024-08-20',0,'영화 소모임',9,12),(17,'신한은행 해커톤입니다.','2024-08-31','ses_EBrU0XVgOb','2024-08-27',0,'신한은행 해커톤',2,14),(18,NULL,'2024-08-24','ses_ORPFvNRSXY','2024-08-19',0,'공통프로젝트',2,14),(19,NULL,'2024-08-30','ses_JNytNutlWw','2024-08-28',0,'알고리즘 4조',2,14),(20,'순천가자','2024-08-27','ses_Cdg1w1eNHU','2024-08-22',0,'순천 여행 ✈️ ',8,20),(21,'ㅇ','2024-08-30','ses_B3ME9tX7DH','2024-08-21',0,'화순 맛집 뿌시기',8,20),(22,'떠나자 우리 ^*^','2024-08-19','ses_PKiDztzX3y','2024-08-17',3,'공통 프로젝트 mt',8,20);
/*!40000 ALTER TABLE `plan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16  7:36:08
